
import SpriteKit
import PlaygroundSupport
// Load the SKScene from 'GameScene.sks'
let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 720, height: 540))
if let scene = GameScene(fileNamed: "GameScene") {
    scene.scaleMode = .aspectFill
    sceneView.presentScene(scene)
}


    PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
