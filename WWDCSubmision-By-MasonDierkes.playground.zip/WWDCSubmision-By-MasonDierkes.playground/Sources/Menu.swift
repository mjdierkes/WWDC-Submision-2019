//: A SpriteKit based Playground

import PlaygroundSupport
import SpriteKit

public class Menu: UIViewController {
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        //let label = UILabel(fr)
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 300, height: 21))
        label.center = CGPoint(x: 160, y: 285)
        label.textAlignment = .center
        label.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        label.numberOfLines = 2
        label.text = "A Brief History of \nApple Frameworks"
        label.font = UIFont(name: "HelveticaNeue-Bold", size: 20)
        self.view.addSubview(label)
        
        label.translatesAutoresizingMaskIntoConstraints = false
        
        label.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        label.widthAnchor.constraint(equalToConstant: 300).isActive = true
        label.heightAnchor.constraint(equalToConstant: 50).isActive = true
        label.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -550).isActive = true
        
        let button = UIButton(frame: CGRect(x: 100, y: 100, width: 100, height: 50))
        button.backgroundColor = #colorLiteral(red: 0.2171868707, green: 0.8181777088, blue: 0.8684964005, alpha: 1)
        button.setTitle("Watch Again", for: .normal)
        button.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        button.layer.cornerRadius = 15
        button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        
        self.view.addSubview(button)
        
        let spriteKitButton = UIButton(frame: CGRect(x: 100, y: 100, width: 100, height: 50))
        spriteKitButton.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        spriteKitButton.setTitle("Sprite Kit", for: .normal)
        spriteKitButton.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: .normal)
        spriteKitButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        spriteKitButton.layer.cornerRadius = 15
        spriteKitButton.addTarget(self, action: #selector(goToGame), for: .touchUpInside)
        
        self.view.addSubview(spriteKitButton)
        
        button.translatesAutoresizingMaskIntoConstraints = false
        
        button.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        button.widthAnchor.constraint(equalToConstant: 150).isActive = true
        button.heightAnchor.constraint(equalToConstant: 50).isActive = true
        button.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -450).isActive = true
        
        spriteKitButton.translatesAutoresizingMaskIntoConstraints = false

        
        spriteKitButton.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        spriteKitButton.widthAnchor.constraint(equalToConstant: 150).isActive = true
        spriteKitButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
        spriteKitButton.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -100).isActive = true
        
        
        let ARKitButton = UIButton(frame: CGRect(x: 100, y: 100, width: 100, height: 50))
        ARKitButton.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        ARKitButton.setTitle("AR Kit", for: .normal)
        ARKitButton.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: .normal)
        ARKitButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        ARKitButton.layer.cornerRadius = 15
        ARKitButton.addTarget(self, action: #selector(arKit), for: .touchUpInside)
        
        self.view.addSubview(ARKitButton)
        
        ARKitButton.translatesAutoresizingMaskIntoConstraints = false
        
        ARKitButton.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        ARKitButton.widthAnchor.constraint(equalToConstant: 150).isActive = true
        ARKitButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
        ARKitButton.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -300).isActive = true
        
        
        let sceneKitBtn = UIButton(frame: CGRect(x: 100, y: 100, width: 100, height: 50))
        sceneKitBtn.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        sceneKitBtn.setTitle("Scene Kit", for: .normal)
        sceneKitBtn.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: .normal)
        sceneKitBtn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        sceneKitBtn.layer.cornerRadius = 15
        sceneKitBtn.addTarget(self, action: #selector(sceneKit), for: .touchUpInside)
        
        self.view.addSubview(sceneKitBtn)
        
        sceneKitBtn.translatesAutoresizingMaskIntoConstraints = false
        
        sceneKitBtn.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        sceneKitBtn.widthAnchor.constraint(equalToConstant: 150).isActive = true
        sceneKitBtn.heightAnchor.constraint(equalToConstant: 50).isActive = true
        sceneKitBtn.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -200).isActive = true
    }
    
    @objc func buttonAction(sender: UIButton!) {
        let frame = CGRect(x: 0, y: 0, width: 720, height: 540)
        let view = SKView(frame: frame)
        let scene  = GameScene(fileNamed: "GameScene")
        scene?.scaleMode = .aspectFill
        view.presentScene(scene)

        PlaygroundPage.current.liveView = view
    }
    
    @objc func goToGame(sender: UIButton!) {
        let frame = CGRect(x: 0, y: 0, width: 720, height: 540)
        let view = SKView(frame: frame)
        let scene  = RocketGame(fileNamed: "SpriteKitGame")
        scene?.scaleMode = .aspectFit
        view.presentScene(scene)
        
        PlaygroundPage.current.liveView = view
    }
    
    
    @objc func arKit(sender: UIButton!) {
        let viewController = QIARViewController()
        
        PlaygroundPage.current.liveView = viewController
    }
    
    @objc func sceneKit(sender: UIButton!) {
        let frame = CGRect(x: 0, y: 0, width: 720, height: 540)
        let view = SKView(frame: frame)
        let scene  = SceneKitGame(fileNamed: "GameScene")
        scene?.scaleMode = .aspectFit
        view.presentScene(scene)
        
        PlaygroundPage.current.liveView = view
    }

    
    
}
