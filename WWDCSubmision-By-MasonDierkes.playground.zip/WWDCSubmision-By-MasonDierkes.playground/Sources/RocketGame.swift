//: A SpriteKit based Playground-

import PlaygroundSupport
import SpriteKit
import UIKit
import GameplayKit


 public class RocketGame: SKScene, SKPhysicsContactDelegate {

    private var scoreLbl : SKLabelNode!
    private var player : SKSpriteNode!
    var starfield:SKEmitterNode!
    private var rocketFuel : SKEmitterNode!
    var torpedoNode : SKSpriteNode!
    var alien : SKSpriteNode!
    
    var gameTimer:Timer!
    
    var possibleAliens = ["alien", "alien2", "alien3"]
    
    let alienCategory:UInt32 = 0x1 << 1
    let photonTorpedoCategory:UInt32 = 0x1 << 0
    let shipCategory:UInt32 = 0x1 << 2
    
    var score : Int = 0

    public override func didMove(to view: SKView) {
        setUp()
        gameTimer = Timer.scheduledTimer(timeInterval: 0.75, target: self, selector: #selector(addAlien), userInfo: nil, repeats: true)

    }
    func setUp(){
        scoreLbl = childNode(withName: "scoreLbl") as? SKLabelNode
        player = childNode(withName: "player") as? SKSpriteNode
        // player.position = view?.bounds.height - 100
        rocketFuel = SKEmitterNode(fileNamed: "RocketFuel")
        rocketFuel.position.y = -40
        player.addChild(rocketFuel)
        updateScore(to: 0)
        scoreLbl.text = "Get to 15"
        let borderBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        borderBody.friction = 0
        self.physicsBody = borderBody

        self.physicsWorld.gravity = CGVector(dx: 0, dy: 0)
        self.physicsWorld.contactDelegate = self

        background()
    }

    func background(){
        starfield = SKEmitterNode(fileNamed: "Starfield")
        starfield.position = CGPoint(x: 0, y: 1472)
        starfield.advanceSimulationTime(10)
        self.addChild(starfield)
        starfield.zPosition = -1
    }



    func fireTorpedo() {
        self.run(SKAction.playSoundFileNamed("torpedo.mp3", waitForCompletion: false))

       torpedoNode = SKSpriteNode(imageNamed: "torpedo")
        torpedoNode.position = player.position
        torpedoNode.position.y += 5
        torpedoNode.setScale(0.3)
        torpedoNode.zPosition = -1
        
        torpedoNode.physicsBody = SKPhysicsBody(circleOfRadius: torpedoNode.size.width / 2)
        torpedoNode.physicsBody?.isDynamic = true
  
         self.addChild(torpedoNode)
        

        torpedoNode.physicsBody?.categoryBitMask = photonTorpedoCategory
        torpedoNode.physicsBody?.collisionBitMask = alienCategory
        torpedoNode.physicsBody?.contactTestBitMask = alienCategory
        
        torpedoNode.physicsBody?.usesPreciseCollisionDetection = true
        
        let animationDuration:TimeInterval = 0.8


        var actionArray = [SKAction]()

        actionArray.append(SKAction.move(to: CGPoint(x: player.position.x, y: self.frame.size.height + 10), duration: animationDuration))
        actionArray.append(SKAction.removeFromParent())

        torpedoNode.run(SKAction.sequence(actionArray))


    }


    func updateScore(to : Int?){
        if to != nil {
            score = to!
            scoreLbl.text = "Score\(score)"
        }
        else{
            score += 1
            scoreLbl.text = "Score \(score)"
        }

    }

    @objc public static override var supportsSecureCoding: Bool {
    
        get {
            return true
        }
    }

    func touchDown(atPoint pos : CGPoint) {

    }

    func touchMoved(toPoint pos : CGPoint) {

    }

    func touchUp(atPoint pos : CGPoint) {

    }

    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }

   public  override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {

            let location = t.location(in: self)
            player.position.x = location.x
        
        }


    }

    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            if (touch.tapCount == 1) {
                fireTorpedo()
                updateScore(to: nil)
                if score >= 15 {
                    nextScreen()
                }
            }
        }
    }


    public override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }

     public override func update(_ currentTime: TimeInterval) {
      
    }
    
    func nextScreen() {
        
        let frame = CGRect(x: 0, y: 0, width: 720, height: 540)
        let view = SKView(frame: frame)
        let scene  = SceneKitGame(fileNamed: "GameScene")
        scene?.scaleMode = .aspectFill
        view.presentScene(scene)
        PlaygroundPage.current.liveView = view
    }
    
    
    
   @objc func addAlien () {
        possibleAliens = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: possibleAliens) as! [String]
        
         alien = SKSpriteNode(imageNamed: possibleAliens[0])
        
        let randomAlienPosition = GKRandomDistribution(lowestValue: -300, highestValue: 400)
        let position = CGFloat(randomAlienPosition.nextInt())
    
        alien.setScale(0.5)
        alien.position = CGPoint(x: position, y: self.frame.size.height + alien.size.height)
        alien.zPosition = -1
    
        alien.physicsBody = SKPhysicsBody(rectangleOf: alien.size)
        alien.physicsBody?.isDynamic = true

        self.addChild(alien)
    
        alien.physicsBody?.categoryBitMask = alienCategory
        alien.physicsBody?.collisionBitMask = photonTorpedoCategory
        alien.physicsBody?.contactTestBitMask = photonTorpedoCategory
   
        let animationDuration:TimeInterval = 6
        var actionArray = [SKAction]()
        
        
        actionArray.append(SKAction.move(to: CGPoint(x: position, y: -alien.frame.height - 200), duration: animationDuration))
        actionArray.append(SKAction.removeFromParent())
        
        alien.run(SKAction.sequence(actionArray))
        
        
    }
    func didBegin(_ contact: SKPhysicsContact) {
        print("Collided")
        
    }

    
    func torpedoDidCollideWithAlien (torpedoNode:SKSpriteNode, alienNode:SKSpriteNode) {
        
        let explosion = SKEmitterNode(fileNamed: "Explosion")!
        explosion.position = alienNode.position
        self.addChild(explosion)
        
        self.run(SKAction.playSoundFileNamed("explosion.mp3", waitForCompletion: false))
        
        torpedoNode.removeFromParent()
        alienNode.removeFromParent()

        self.run(SKAction.wait(forDuration: 2)) {
            explosion.removeFromParent()
        }
        score += 5
        
    }
    
    
    
}

