//: A UIKit based Playground for presenting user interface

import UIKit
import QuartzCore
import SceneKit
import PlaygroundSupport


public class Earth: UIViewController {
let scene = SCNScene()
let scnView = SCNView(frame: CGRect(x:0 , y:0, width: 720, height: 540))

    
     func play() {
        
        scnView.scene = scene
        scnView.allowsCameraControl = true
        scnView.autoenablesDefaultLighting = true
        scnView.showsStatistics = true
        scnView.backgroundColor = UIColor.black 
        
        let sphereGeometry = SCNSphere(radius: 2)
        sphereGeometry.firstMaterial?.diffuse.contents = UIImage(named: "world.topo.bathy.200412.3x5400x2700.png")
        let sphereNode = SCNNode(geometry: sphereGeometry)
        sphereNode.position = SCNVector3Zero
        scene.rootNode.addChildNode(sphereNode)
        
        
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3Make(0, 0, 8)
        scene.rootNode.addChildNode(cameraNode)
        
        let omniLight = SCNLight()
        omniLight.type = SCNLight.LightType.omni
        let omniLightNode = SCNNode()
        omniLightNode.light = omniLight
        omniLightNode.position = SCNVector3Make(10, 10, 10)
        scene.rootNode.addChildNode(omniLightNode)
    }
    

    
}

