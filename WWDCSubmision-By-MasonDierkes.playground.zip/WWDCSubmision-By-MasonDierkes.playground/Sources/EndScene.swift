//: A SpriteKit based Playground

import PlaygroundSupport
import SpriteKit

public class EndScene: SKScene {
    
    private var label : SKLabelNode!
    private var primaryImage : SKSpriteNode!
    private var secondaryLbl : SKLabelNode!
    private var secondaryImage : SKSpriteNode!
    private var spriteKitLogo : SKSpriteNode!
    private var spriteKitBuble : SKSpriteNode!
    private var sceneKitBuble : SKSpriteNode!
    private var sencondarySceneBuble : SKSpriteNode!
    
    
    public override func didMove(to view: SKView) {
        setUp()
        startSequence()
    }
    
    func setUp(){
        label = childNode(withName: "mainLabel") as? SKLabelNode
        primaryImage = childNode(withName: "apple") as? SKSpriteNode
        secondaryLbl = childNode(withName: "secondaryLbl") as? SKLabelNode
        secondaryImage = childNode(withName: "secondaryImage") as? SKSpriteNode
        spriteKitLogo = childNode(withName: "spriteKitLogo") as? SKSpriteNode
        spriteKitBuble = childNode(withName: "spriteKitBuble") as? SKSpriteNode
        sceneKitBuble = childNode(withName: "sceneKitBuble") as? SKSpriteNode
        sencondarySceneBuble = childNode(withName: "sencondarySceneBuble") as? SKSpriteNode
        
        
        spriteKitBuble.isHidden = true
        sceneKitBuble.isHidden = true
        spriteKitLogo.isHidden = true
        sencondarySceneBuble.isHidden = true
        secondaryImage.isHidden = true
        primaryImage.isHidden = true
        secondaryLbl.isHidden = true
        
    }
    
    func startSequence(){
      
        primaryImage.isHidden = true
        label.text = "Whats Next? "
        secondaryLbl.isHidden = false
        secondaryLbl.fontColor = #colorLiteral(red: 0, green: 0.4784313725, blue: 1, alpha: 1)
        secondaryLbl.text = "@apple"
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(5), execute: {
            let viewController = Menu()
            PlaygroundPage.current.liveView = viewController
        })
    }
  
    
    func colorFlip(){
        if label.color == #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0){
            label.fontColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
            backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        }
        else if label.color == #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1){
            label.fontColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        }
    }
    

  
}
