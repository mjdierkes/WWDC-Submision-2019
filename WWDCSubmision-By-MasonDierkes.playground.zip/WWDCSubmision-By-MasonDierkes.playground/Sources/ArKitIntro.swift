//: A SpriteKit based Playground

import PlaygroundSupport
import SpriteKit

public class ArKitIntro: SKScene {
    
    private var label : SKLabelNode!
    private var primaryImage : SKSpriteNode!
    private var secondaryLbl : SKLabelNode!
    private var secondaryImage : SKSpriteNode!
    private var spriteKitLogo : SKSpriteNode!
    private var spriteKitBuble : SKSpriteNode!
    private var sceneKitBuble : SKSpriteNode!
    private var sencondarySceneBuble : SKSpriteNode!
    

    public override func didMove(to view: SKView) {
        setUp()
        intro()
    }
    
    func setUp(){
        label = childNode(withName: "mainLabel") as? SKLabelNode
        primaryImage = childNode(withName: "apple") as? SKSpriteNode
        secondaryLbl = childNode(withName: "secondaryLbl") as? SKLabelNode
        secondaryImage = childNode(withName: "secondaryImage") as? SKSpriteNode
        spriteKitLogo = childNode(withName: "spriteKitLogo") as? SKSpriteNode
        spriteKitBuble = childNode(withName: "spriteKitBuble") as? SKSpriteNode
        sceneKitBuble = childNode(withName: "sceneKitBuble") as? SKSpriteNode
        sencondarySceneBuble = childNode(withName: "sencondarySceneBuble") as? SKSpriteNode
        
        
        spriteKitBuble.isHidden = true
        sceneKitBuble.isHidden = true
        spriteKitLogo.isHidden = true
        sencondarySceneBuble.isHidden = true
        secondaryImage.isHidden = true
        primaryImage.isHidden = true
        secondaryLbl.isHidden = true

    }
    
    func intro(){
        label.text = "But that's not all!"
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
            self.label.isHidden = true
            self.primaryImage.isHidden = false
            self.secondaryLbl.isHidden = false
            self.primaryImage.texture = SKTexture(imageNamed: "arKitLogo")
             self.secondaryLbl.text = "AR Kit"
                DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                    PlaygroundPage.current.liveView = QIARViewController()
                })
            })
        }
    
    
    func colorFlip(){
        if label.color == #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0){
            label.fontColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
            backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        }
        else if label.color == #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1){
            label.fontColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        }
    }
    
    func nextScreen() {
        
        let frame = CGRect(x: 0, y: 0, width: 720, height: 540)
        let view = SKView(frame: frame)
        let scene  = RocketGame(fileNamed: "SpriteKitGame")
        scene?.scaleMode = .aspectFit
        view.presentScene(scene)
        PlaygroundPage.current.liveView = view
    }
}
