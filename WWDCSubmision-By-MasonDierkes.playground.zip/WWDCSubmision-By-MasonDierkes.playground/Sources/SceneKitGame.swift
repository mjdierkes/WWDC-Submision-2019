


import Foundation
import UIKit
import QuartzCore
import SceneKit
import PlaygroundSupport
import SpriteKit

public class SceneKitGame: SKScene {
    
    private var label : SKLabelNode!
    private var primaryImage : SKSpriteNode!
    private var secondaryLbl : SKLabelNode!
    private var spriteKitLogo : SKSpriteNode!
    private var spriteKitBuble : SKSpriteNode!
    private var sceneKitBuble : SKSpriteNode!
    private var sencondarySceneBuble : SKSpriteNode!
    private var secondaryImage : SKSpriteNode!
    
    public override func didMove(to view: SKView) {
        
        setUp()
        
    }
    
    func setUp(){
        label = childNode(withName: "mainLabel") as? SKLabelNode
        primaryImage = childNode(withName: "apple") as? SKSpriteNode
        secondaryLbl = childNode(withName: "secondaryLbl") as? SKLabelNode
        spriteKitLogo = childNode(withName: "spriteKitLogo") as? SKSpriteNode
        spriteKitBuble = childNode(withName: "spriteKitBuble") as? SKSpriteNode
        sceneKitBuble = childNode(withName: "sceneKitBuble") as? SKSpriteNode
        sencondarySceneBuble = childNode(withName: "sencondarySceneBuble") as? SKSpriteNode
        secondaryImage = childNode(withName: "secondaryImage") as? SKSpriteNode
        
        label.text = ""
        primaryImage.isHidden = true
        secondaryLbl.isHidden = true
        sceneKitSequence()
        spriteKitBuble.isHidden = true
        spriteKitLogo.isHidden = true
        sceneKitBuble.isHidden = true
        sencondarySceneBuble.isHidden = true
        secondaryImage.isHidden = true
    }
    

    
    func sceneKitSequence(){
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
            self.label.text = "That was cool"
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                self.colorFlip()
                self.label.text = "Right?"
                
                DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                    self.textingSequenece()
                
                DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(5), execute: {
                    self.nextScreen()
                    DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(30), execute: {
                        let frame = CGRect(x: 0, y: 0, width: 720, height: 540)
                        let view = SKView(frame: frame)
                        let scene  = ArKitIntro(fileNamed: "GameScene")
                        scene?.scaleMode = .aspectFit
                        view.presentScene(scene)
                        PlaygroundPage.current.liveView = view
                    })
                })
            })
            })
    })
    }
    
    func textingSequenece(){
        
       backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
       spriteKitBuble.isHidden = false
       spriteKitLogo.isHidden = false
        sceneKitBuble.isHidden = false
        secondaryImage.isHidden = false
        
        label.isHidden = true
       let scale = SKAction.scale(by: 1.5, duration: 0.3)
        let move = SKAction.moveBy(x: -50, y: 20, duration: 0.3)
        let moveUpAndOut = SKAction.moveBy(x: 0, y: sceneKitBuble.frame.height + 30, duration: 0.3)
        sceneKitBuble.run(scale)
        sceneKitBuble.run(move)
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
            self.sceneKitBuble.run(moveUpAndOut)
            self.sencondarySceneBuble.isHidden = false
            self.sencondarySceneBuble.run(scale)
            self.sencondarySceneBuble.run(move)
        })
        
        
    }
    
    func eclipseTextAnimation(text : String, labelName : SKLabelNode){
        labelName.text = ""
        for char in text {
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                labelName.text = "\(char)"
            })
        }
    }
   
    
    func colorFlip(){
        if label.color == #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0){
            label.fontColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
            backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        }
        else if label.color == #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1){
            label.fontColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        }
    }
    
    
    func playEarth(){
        let scene = SCNScene() // 1
        let scnView = SCNView(frame: CGRect(x:0 , y:0, width: 720, height: 540))
        let textLayer = SKScene(size: CGSize(width: 720, height: 540))
        let backButton = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        backButton.numberOfLines = 2
        backButton.text = """
        2019 - 100% Renewable
        Energy
        """
        backButton.fontSize = 30
        backButton.name = "backbutton"
        backButton.fontColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        textLayer.addChild(backButton) // self is GameScene (an SKScene)
        backButton.zPosition = 1
        backButton.position = CGPoint(x: (textLayer.frame.maxX / 2) + 150, y: (textLayer.frame.maxY / 2 ) - 20)
        
        let directionLbl = SKLabelNode(fontNamed: "HelveticaNeue-Light")
        directionLbl.color = #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)
        directionLbl.text = "Change the world. With a swipe of a finger."
        textLayer.addChild(directionLbl)
        directionLbl.fontSize = 10
        directionLbl.position = CGPoint(x: (textLayer.frame.maxX / 2), y: backButton.position.y - 200)
        
        
            scnView.scene = scene // 3
            scnView.allowsCameraControl = true // 4
            scnView.autoenablesDefaultLighting = true // 5
            scnView.backgroundColor = UIColor.black // 7
            textLayer.scaleMode = .aspectFit
            scnView.overlaySKScene = textLayer
        
            let sphereGeometry = SCNSphere(radius: 4)
            sphereGeometry.firstMaterial?.diffuse.contents = UIImage(named: "world.topo.bathy.200412.3x5400x2700.png")
            let sphereNode = SCNNode(geometry: sphereGeometry)
            sphereNode.position = SCNVector3Zero
            scene.rootNode.addChildNode(sphereNode)
            
            
            let cameraNode = SCNNode()
            cameraNode.camera = SCNCamera()
            cameraNode.position = SCNVector3Make(5, 0, 8)
            scene.rootNode.addChildNode(cameraNode)
            
            let omniLight = SCNLight()
            omniLight.type = SCNLight.LightType.omni
            let omniLightNode = SCNNode()
            omniLightNode.light = omniLight
            omniLightNode.position = SCNVector3Make(10, 10, 5)
            scene.rootNode.addChildNode(omniLightNode)
    
        sphereNode.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: 1, z: 0, duration: 10)))

         PlaygroundPage.current.liveView = scnView
    }
    
    func nextScreen() {
        
       playEarth()
       
       
    }
}







