//: A UIKit based Playground to present an ARSKScene so you can play with ARKit in a playground

import UIKit
import ARKit
import PlaygroundSupport
import SpriteKit

public class QIARViewController : UIViewController, ARSCNViewDelegate, ARSessionDelegate {
    var sceneView: ARSCNView!
    
   public override func loadView() {
    

        sceneView = ARSCNView(frame:CGRect(x: 0.0, y: 0.0, width: 500.0, height: 600.0))
        sceneView.delegate = self
        
        sceneView.autoenablesDefaultLighting = true

        let config = ARWorldTrackingConfiguration()
        config.planeDetection = .horizontal
        sceneView.session.delegate = self
        
        self.view = sceneView
        sceneView.session.run(config)
    
    let button = UIButton(frame: CGRect(x: 100, y: 100, width: 100, height: 50))
    button.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0.8480575771)
    button.setTitle("Continue", for: .normal)
    button.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: .normal)
    button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
    button.layer.cornerRadius = 15
    button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
    
    self.view.addSubview(button)
    
    button.translatesAutoresizingMaskIntoConstraints = false
    
    button.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
    button.widthAnchor.constraint(equalToConstant: 100).isActive = true
    button.heightAnchor.constraint(equalToConstant: 50).isActive = true
    button.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -20).isActive = true
    
    }
    
    @objc func buttonAction(sender: UIButton!) {
        print("Button tapped")
        nextScene()
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let touchLocation = touch.location(in: sceneView)
            let results = sceneView.hitTest(touchLocation, types: .existingPlaneUsingExtent)
            if let hitResult = results.first {
                let diceScene = SCNScene(named: "WWDC.scn")!
                if let diceNode = diceScene.rootNode.childNode(withName: "object", recursively: true) {
                    diceNode.position = SCNVector3(
                        x: hitResult.worldTransform.columns.3.x,
                        y: hitResult.worldTransform.columns.3.y,
                        z: hitResult.worldTransform.columns.3.z
                    )
                    sceneView.scene.rootNode.addChildNode(diceNode)
                    
                }
            }
        }
    }
    
    
    func view(_ view: ARSKView, nodeFor anchor: ARAnchor) -> SKNode? {
      
        let diceScene = SCNScene(named: "dice")!
        if let diceNode = diceScene.rootNode.childNode(withName: "Dice", recursively: true){
            print("good")
            sceneView.scene.rootNode.addChildNode(diceNode)
        }

        let spriteNode = SKLabelNode(text: "👾")
        spriteNode.horizontalAlignmentMode = .center
        spriteNode.verticalAlignmentMode = .center

        return spriteNode;
    }
    
    func session(_ session: ARSession, didFailWithError error: Error) {
    
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
      
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
    }
}

func nextScene (){
    let frame = CGRect(x: 0, y: 0, width: 720, height: 540)
    let view = SKView(frame: frame)
    let scene  = EndScene(fileNamed: "GameScene")
    view.presentScene(scene)
    PlaygroundPage.current.liveView = view
}







public class Scene: SKScene {
    
    public override required init(size:CGSize) {
        super.init(size:size)
    }
    
    public required init(coder: NSCoder) {
        super.init(coder:coder)!
    }
    public override func didMove(to view: SKView) {
    }
    
    public override func update(_ currentTime: TimeInterval) {
    }
}

