//: A SpriteKit based Playground

import PlaygroundSupport
import SpriteKit

public class GameScene: SKScene {
    
    private var label : SKLabelNode!
    private var primaryImage : SKSpriteNode!
    private var secondaryLbl : SKLabelNode!
    private var secondaryImage : SKSpriteNode!
    private var spriteKitLogo : SKSpriteNode!
    private var spriteKitBuble : SKSpriteNode!
    private var sceneKitBuble : SKSpriteNode!
    private var sencondarySceneBuble : SKSpriteNode!

    let textArray = ["This is Big", "The iPhone Was Introduced"]
    var images = [0: "apple-logo",
                  1: "steveJobs",
                  404: "File not found",
                  500: "Internal server error"]
    var imageNumber = 0
    public override func didMove(to view: SKView) {
        setUp()
        secondaryImage.isHidden = true
        label.text = "This is BIG"
        startSequence()
        
    }
    
    func setUp(){
        label = childNode(withName: "mainLabel") as? SKLabelNode
        primaryImage = childNode(withName: "apple") as? SKSpriteNode
        secondaryLbl = childNode(withName: "secondaryLbl") as? SKLabelNode
        secondaryImage = childNode(withName: "secondaryImage") as? SKSpriteNode
       spriteKitLogo = childNode(withName: "spriteKitLogo") as? SKSpriteNode
        spriteKitBuble = childNode(withName: "spriteKitBuble") as? SKSpriteNode
        sceneKitBuble = childNode(withName: "sceneKitBuble") as? SKSpriteNode
        sencondarySceneBuble = childNode(withName: "sencondarySceneBuble") as? SKSpriteNode

        
        spriteKitBuble.isHidden = true
        sceneKitBuble.isHidden = true
        spriteKitLogo.isHidden = true
        sencondarySceneBuble.isHidden = true

                let backgroundSound = SKAudioNode(fileNamed: "BackgroundSong.mp3")
                self.addChild(backgroundSound)
    }
    
    func startSequence(){
        primaryImage.texture = SKTexture(imageNamed: "apple-logo")
        secondaryLbl.isHidden = true
        label.isHidden = true
        self.textSequence()
    }
    
    func iPhoneSequence(){
        let superScale = SKAction.scale(by: 3, duration: 1)
        self.primaryImage.isHidden = false
        self.primaryImage.run(SKAction.setTexture(SKTexture(imageNamed: "steveJobs.jpg"), resize: true))
        self.secondaryLbl.isHidden = false
        self.secondaryLbl.text = "The iPhone"
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2), execute: {
            self.appStore()
            
        })
    }
    
    func appStore(){
        primaryImage.isHidden = true
        secondaryLbl.isHidden = true
        label.text = "Then in 2008"
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
            self.primaryImage.isHidden = false
            self.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            self.primaryImage.run(SKAction.setTexture(SKTexture(imageNamed: "AppStore"), resize: true))
            self.label.isHidden = true
            self.secondaryLbl.isHidden = false
            self.secondaryLbl.text = "App Store"
            self.appStore2()
        })
        
        
    }
    
    func appStore2(){
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
            self.secondaryLbl.isHidden = true
            self.primaryImage.isHidden = true
            self.label.isHidden = false
            self.label.fontColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
            self.label.text = "Empowering Developers"
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                self.label.text = "ohh..."
                DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                    self.emojis()
                })
            })
        })
    }
    
    func emojis(){
        backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        label.text = "And Did I Forget"
        label.fontColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
            let emojis = SKEmitterNode(fileNamed: "emojis.sks")
            self.label.addChild(emojis!)
            self.label.text = "Emojis"
            Timer.scheduledTimer(timeInterval: 3.55, target: self, selector: #selector(self.spriteKit), userInfo: nil, repeats: false)

        })
    }
    
    @objc  func spriteKit(){
        self.label.removeAllChildren()
        label.text = "Then 2014"
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
            self.primaryImage.isHidden = false
            self.primaryImage.texture = SKTexture(imageNamed: "spriteKitLogo")
            self.secondaryLbl.text = "Sprite Kit"
            self.secondaryLbl.isHidden = false
            self.label.isHidden = true
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                self.primaryImage.isHidden = true
                self.secondaryLbl.isHidden = true
                self.label.isHidden = false
                self.label.text = "Now You Could"
                DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                    self.label.text = "Create games like..."
                    DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                        self.nextScreen()
                        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                            self.label.text = "That was cool"
                            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                                self.colorFlip()
                                self.label.text = "Right?"
                            })
                        })
                    })
                })
            })
        })
    }
    
    
    func sceneKitSequence(){
        
    }
    
    func eclipseTextAnimation(text : String, labelName : SKLabelNode){
        labelName.text = ""
        for char in text {
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                labelName.text = "\(char)"
            })
        }
    }
    func textSequence(){
        label.isHidden = false
        primaryImage.isHidden = true
        secondaryLbl.isHidden = true
        
        self.label.text = "A brief history of "

        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
            self.label.text = "Apple Frameworks"
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
            self.label.text = "2007"
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                self.iPhoneSequence()
            })
        })
        })

    }
    
    func changeImage(imageNamed: String){
        print(imageNumber)
        primaryImage.isHidden = false
        let image = SKTexture(imageNamed: imageNamed)
        print(imageNamed)
        primaryImage.texture = image
        primaryImage.isHidden = true
        imageNumber += 1
    }
    
    func colorFlip(){
        if label.color == #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0){
            label.fontColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
            backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        }
        else if label.color == #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1){
            label.fontColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        }
    }
    
    
    
    
    func typWriter(text: String, label : SKLabelNode){
        let text = ["G", "a", "m", "e"]
        var labelText = ""
        var calls : Int = 0
        var timer : Timer!
        func changeText(view: SKView) {
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2), execute: {
                labelText += text[calls]
                label.text = labelText
                calls += 1
                if calls == text.count + 1 {
                    timer.invalidate()
                }
            })
            label.text = labelText
        }
        
    }
    
    func nextScreen() {
        
        let frame = CGRect(x: 0, y: 0, width: 720, height: 540)
        let view = SKView(frame: frame)
        let scene  = RocketGame(fileNamed: "SpriteKitGame")
        scene?.scaleMode = .aspectFit
        view.presentScene(scene)
        PlaygroundPage.current.liveView = view
    }
}
